# VOUFICARLOUCO

Repositório limpo para curso ou app integrado com Firebase Studio + Next.js.
Subido sem arquivos grandes (como node_modules ou builds).

🚀 Pronto para push e deploy!

