# Curso Team Veo 3
Este repositório contém os arquivos do curso integrado com Firebase Studio.
