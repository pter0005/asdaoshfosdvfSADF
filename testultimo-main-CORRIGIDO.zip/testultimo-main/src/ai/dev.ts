
// Flows will be imported for their side effects in this file.
import './flows/veo3-prompt-generator-flow';
import './flows/simple-chat-flow'; 
import './flows/system-prompt-creator-flow';
